"""
HEC India — Contact Form Backend (Python / Flask)
---------------------------------------------------
Receives the "Request Free Consultation" form from index.html at
POST /api/contact and emails it to the school's inbox.

Run locally:
    pip install -r requirements.txt --break-system-packages
    export SMTP_HOST=smtp.gmail.com
    export SMTP_PORT=587
    export SMTP_USER=your-address@gmail.com
    export SMTP_PASS=your-app-password
    export TO_EMAIL=rhlife.hilal@gmail.com
    python server.py

Then in index.html, set:
    const API_BASE = "http://127.0.0.1:5000";   (local)
    const API_BASE = "https://your-deployed-url";  (production)

Deploy anywhere that runs Python: Render, Railway, PythonAnywhere,
a VPS with gunicorn, etc. Gmail users need an "App Password", not
the normal account password (Google Account -> Security -> App Passwords).
"""

import os
import smtplib
from email.message import EmailMessage

from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # allow the site (any origin) to call this API

SMTP_HOST = os.environ.get("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER = os.environ.get("SMTP_USER", "")
SMTP_PASS = os.environ.get("SMTP_PASS", "")
TO_EMAIL = os.environ.get("TO_EMAIL", "rhlife.hilal@gmail.com")

REQUIRED_FIELDS = ["school_name", "contact_person", "phone", "email"]


@app.route("/api/contact", methods=["POST"])
def contact():
    data = request.get_json(silent=True) or {}

    missing = [f for f in REQUIRED_FIELDS if not str(data.get(f, "")).strip()]
    if missing:
        return jsonify({"ok": False, "error": f"Missing fields: {', '.join(missing)}"}), 400

    body = (
        f"New consultation request from hecindia.in\n\n"
        f"School name     : {data.get('school_name')}\n"
        f"Contact person  : {data.get('contact_person')}\n"
        f"Phone           : {data.get('phone')}\n"
        f"Email           : {data.get('email')}\n"
        f"Service required: {data.get('service', '-')}\n"
        f"Message         : {data.get('message', '-')}\n"
    )

    msg = EmailMessage()
    msg["Subject"] = f"New enquiry — {data.get('school_name')}"
    msg["From"] = SMTP_USER or TO_EMAIL
    msg["To"] = TO_EMAIL
    if data.get("email"):
        msg["Reply-To"] = data["email"]
    msg.set_content(body)

    if not SMTP_USER or not SMTP_PASS:
        # No SMTP configured yet — log instead of failing, so the demo still works.
        print("=== SMTP not configured, printing message instead ===")
        print(body)
        return jsonify({"ok": True, "note": "Logged only — SMTP not configured yet"}), 200

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.send_message(msg)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"ok": False, "error": str(exc)}), 500

    return jsonify({"ok": True}), 200


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=True)
