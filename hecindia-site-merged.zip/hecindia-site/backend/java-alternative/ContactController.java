// HEC India — Contact Form Backend (Java / Spring Boot equivalent)
// -----------------------------------------------------------------
// Drop this into a Spring Boot project (start one at https://start.spring.io
// with the "Spring Web" and "Spring Mail" dependencies) as:
//   src/main/java/in/hecindia/api/ContactController.java
//
// Add to application.properties:
//   spring.mail.host=smtp.gmail.com
//   spring.mail.port=587
//   spring.mail.username=your-address@gmail.com
//   spring.mail.password=your-app-password
//   spring.mail.properties.mail.smtp.auth=true
//   spring.mail.properties.mail.smtp.starttls.enable=true
//   hecindia.to-email=rhlife.hilal@gmail.com
//
// Run with: ./mvnw spring-boot:run   (defaults to http://localhost:8080)
// Then point index.html's API_BASE at wherever this is deployed.

package in.hecindia.api;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@CrossOrigin(origins = "*") // allow the static site to call this API
@RequestMapping("/api")
public class ContactController {

    private final JavaMailSender mailSender;

    @Value("${hecindia.to-email:rhlife.hilal@gmail.com}")
    private String toEmail;

    public ContactController(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    @PostMapping("/contact")
    public ResponseEntity<Map<String, Object>> contact(@RequestBody Map<String, String> data) {
        for (String field : new String[]{"school_name", "contact_person", "phone", "email"}) {
            if (data.get(field) == null || data.get(field).isBlank()) {
                return ResponseEntity.badRequest().body(Map.of("ok", false, "error", "Missing field: " + field));
            }
        }

        String body = String.format(
            "New consultation request from hecindia.in%n%n" +
            "School name     : %s%n" +
            "Contact person  : %s%n" +
            "Phone           : %s%n" +
            "Email           : %s%n" +
            "Service required: %s%n" +
            "Message         : %s%n",
            data.get("school_name"), data.get("contact_person"), data.get("phone"),
            data.get("email"), data.getOrDefault("service", "-"), data.getOrDefault("message", "-")
        );

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(toEmail);
        message.setReplyTo(data.get("email"));
        message.setSubject("New enquiry — " + data.get("school_name"));
        message.setText(body);

        try {
            mailSender.send(message);
        } catch (Exception ex) {
            return ResponseEntity.status(500).body(Map.of("ok", false, "error", ex.getMessage()));
        }

        return ResponseEntity.ok(Map.of("ok", true));
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "ok");
    }
}
